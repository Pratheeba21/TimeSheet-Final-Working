// src/components/LeadPage.js
import React, { useEffect, useState } from "react";
import axios from "axios";
import "./LeadPage.css"; // Add appropriate styling

const LeadPage = () => {
  const [timesheets, setTimesheets] = useState([]);
  const [filteredTimesheets, setFilteredTimesheets] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [employeeId, setEmployeeId] = useState(""); // State for Employee ID filter

  useEffect(() => {
    fetchTimesheets();
  }, []);

  const fetchTimesheets = async () => {
    try {
      const response = await axios.get(
        "http://localhost:8000/api/lead-timesheets/"
      );
      const sortedTimesheets = response.data.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
      setTimesheets(sortedTimesheets);
      setFilteredTimesheets(sortedTimesheets);
    } catch (error) {
      console.error("Error fetching timesheets:", error);
    }
  };

  const handleApproval = async (timesheetId, approvalStatus) => {
    try {
      await axios.put(
        `http://localhost:8000/api/lead-timesheets/${timesheetId}/`,
        {
          lead_approval: approvalStatus,
        }
      );
      fetchTimesheets(); // Refresh timesheets after approval/rejection
    } catch (error) {
      console.error("Error updating timesheet:", error);
    }
  };

  const handleDateChange = (e) => {
    const dateValue = e.target.value;
    const date = new Date(dateValue);

    if (!isNaN(date.getTime())) {
      const formattedDate = date.toISOString().split("T")[0];
      setSelectedDate(formattedDate);
      filterTimesheets(employeeId, formattedDate);
    } else {
      console.error("Invalid date value:", dateValue);
    }
  };

  const handleEmployeeIdChange = (e) => {
    const id = e.target.value;
    setEmployeeId(id);
    filterTimesheets(id, selectedDate);
  };

  const filterTimesheets = (id, date) => {
    const filtered = timesheets.filter(
      (t) => (!date || t.date === date) && (!id || t.emp_id === id)
    );
    setFilteredTimesheets(filtered);
  };

  const handleShowAll = () => {
    setSelectedDate(null);
    setEmployeeId("");
    setFilteredTimesheets(timesheets);
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    return `${date.toISOString().split("T")[0]} ${
      date.toTimeString().split(" ")[0]
    }`;
  };

  const renderTimesheetDetails = () => {
    if (!filteredTimesheets.length) return <p>No entries available</p>;

    return (
      <div className="timesheet-details">
        <h3>
          {selectedDate
            ? `Timesheet Details for ${selectedDate}`
            : "All Timesheet Entries"}
        </h3>
        <table>
          <thead>
            <tr>
              <th>Employee ID</th>
              <th>Employee Name</th>
              <th>Date</th>
              <th>Project Name</th>
              <th>Start Time</th>
              <th>End Time</th>
              <th>Total Hours</th>
              <th>Timestamp</th>
              <th>Comments</th>
              <th>Lead Approval</th>
            </tr>
          </thead>
          <tbody>
            {filteredTimesheets.map((timesheet) => (
              <tr key={timesheet.id}>
                <td>{timesheet.emp_id || "N/A"}</td>
                <td>{timesheet.emp_name || "N/A"}</td>
                <td>{timesheet.date}</td>
                <td>{timesheet.project_name}</td>
                <td>{timesheet.start_time}</td>
                <td>{timesheet.end_time}</td>
                <td>{timesheet.total_hours}</td>
                <td>{formatTimestamp(timesheet.timestamp)}</td>
                <td>{timesheet.comments}</td>
                <td>
                  {timesheet.lead_approval === "pending" ? (
                    <>
                      <button
                        onClick={() => handleApproval(timesheet.id, "approved")}
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => handleApproval(timesheet.id, "rejected")}
                      >
                        Reject
                      </button>
                    </>
                  ) : (
                    timesheet.lead_approval
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="lead-content">
      <div className="lead-inner-content">
        <h1>Lead Timesheet View</h1>
        <div className="filter-container">
          <div className="filter-box">
            <input
              id="employee-id"
              type="text"
              value={employeeId}
              onChange={handleEmployeeIdChange}
              placeholder="Enter Employee ID"
            />
          </div>
          <div className="date-selector">
            <input type="date" onChange={handleDateChange} />
            <button onClick={handleShowAll}>Show All</button>
          </div>
        </div>
        {renderTimesheetDetails()}
      </div>
    </div>
  );
};

export default LeadPage;
