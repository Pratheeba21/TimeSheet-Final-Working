import axios from 'axios';
const API_URL = 'http://localhost:8000/api/timesheet/';
// const timesheetService = {
//     addTimesheet: (empId, date, projectName, startTime, endTime, comments) => {
//         return axios.post(API_URL, {
//             emp: empId,
//             date: date,
//             project_name: projectName,
//             start_time: startTime,
//             end_time: endTime,
//             comments: comments,
//         }, {
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Accept': 'application/json'
//             }
//         });
//     },
//     getTimesheets: (empId) => {
//         return axios.get(API_URL, {
//             params: { emp: empId },
//             headers: {
//                 'Accept': 'application/json'
//             }
//         });
//     }
// };
const timesheetService = {
    addTimesheet: (empId, date, projectName,projectModule,startTime, endTime, comments) => {
        return axios.post(API_URL, {
            emp: empId,
            date: date,
            project_name: projectName,
            project_module:projectModule,
            start_time: startTime,
            end_time: endTime,
            comments: comments,
        }, {
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });
    },
    getTimesheets: (empId) => {
        return axios.get(API_URL, {
            params: { emp: empId },
            headers: {
                'Accept': 'application/json'
            }
        });
    },
    getProjects: (empId) => {
        return axios.get('http://localhost:8000/api/projects/', {
            params: { emp_id: empId },
            headers: {
                'Accept': 'application/json'
            }
        });
    },
    getModules: (projectId) => {
        return axios.get(`http://localhost:8000/api/modules/${projectId}/`, {
            headers: {
                'Accept': 'application/json'
            }
        });
    }
};

export default timesheetService;