from django.db import models
from django.utils import timezone

class Employee(models.Model):
    EMPLOYEE_STATUS_CHOICES = [
        ('Employee', 'Employee'),
        ('Manager', 'Manager'),
        ('Lead', 'Lead'),
    ]

    emp_id = models.CharField(max_length=10, primary_key=True)
    emp_name = models.CharField(max_length=100)
    email_id = models.EmailField(unique=True)
    password = models.CharField(max_length=100)
    joining_date = models.DateField(default=timezone.now)
    timestamp = models.DateTimeField(auto_now_add=True)
    person_status = models.CharField(max_length=10, choices=EMPLOYEE_STATUS_CHOICES, default='Employee')

    def __str__(self):
        return self.emp_id


class Project(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('finished', 'Finished'),
    ]

    emp = models.ForeignKey(Employee, on_delete=models.CASCADE)
    project_name = models.CharField(max_length=100)
    project_module = models.CharField(max_length=100)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.project_name} - {self.emp.emp_name}"


class Timesheet(models.Model):
    emp = models.ForeignKey(Employee, on_delete=models.CASCADE)
    date = models.DateField()
    project_name = models.CharField(max_length=100, editable=False)
    start_time = models.TimeField()
    end_time = models.TimeField()
    comments = models.TextField()
    total_hours = models.DecimalField(max_digits=5, decimal_places=2)
    lead_approval = models.CharField(max_length=20, choices=[('pending', 'pending'), ('approved', 'approved'), ('rejected', 'rejected')], default='pending')
    manager_approval = models.CharField(max_length=20, choices=[('pending', 'pending'), ('approved', 'approved'), ('rejected', 'rejected')], default='pending')
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.emp} - {self.date}"

    def save(self, *args, **kwargs):
        if not self.project_name:
            project = Project.objects.filter(emp=self.emp).first()
            if project:
                self.project_name = project.project_name
            else:
                raise ValueError("No project assigned to this employee.")
        super(Timesheet, self).save(*args, **kwargs)
